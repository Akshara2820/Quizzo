export const CollectionData = [
    {id:1, image:'../assets/education.jpg', heading:'Education', link_:'/collection/education'},
    {id:2, image:'../assets/car.jpg', heading:'Game',  link_:'/collection/games'},
    {id:3, image:'../assets/food.jpg', heading:'Food',  link_:'/collection/food'},
    {id:4, image:'../assets/school.jpg', heading:'School',  link_:'/collection/school'},
    {id:5, image:'../assets/music.jpg', heading:'Music',  link_:'/collection/music'},
    {id:6, image:'../assets/bulb.jpg', heading:'Motivation',  link_:'/collection/motivation'},
    {id:7, image:'../assets/growup.webp', heading:'Grow Up', link_:'/collection/grow-up'},
    {id:8, image:'../assets/play.jpg', heading:'Players',  link_:'/collection/play'},
    {id:9, image:'../assets/food.jpg', heading:'Food',  link_:'/collection/food'},
    {id:10, image:'../assets/piggy_bank.jpg', heading:'Saving',  link_:'/collection/saving'},
    {id:11, image:'../assets/puzzle.webp', heading:'Business',  link_:'/collection/business'},
    {id:12, image:'../assets/bulb.jpg', heading:'Motivation',  link_:'/collection/motivation'},
    
]